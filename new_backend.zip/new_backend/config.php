<?php
declare(strict_types=1);

/**
 * config.php
 * DB + bootstrap
 *
 * Edit DB_USER and DB_PASS to match your XAMPP MySQL settings.
 */

session_start();

// Database settings
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'dbo_schema');   // as you said
define('DB_USER', 'root');         // XAMPP default
define('DB_PASS', '');             // XAMPP default empty password

// If you want to enforce the Google client id on token verification, put it here.
// Example from your OAuth Playground snippet: '407408718192.apps.googleusercontent.com'
define('GOOGLE_CLIENT_ID', ''); // <-- set if you want to check aud (recommended)

// Base URL used for redirects (update if you place the folder under a different path).
// Example: if backend is in /mimar-backend/backend/ then BASE_URL might be '/mimar-backend'
define('BASE_URL', ''); // leave empty if you serve from webroot

// Allowed roles (keep in sync with DB)
$ALLOWED_ROLES = ['client', 'contractor', 'admin'];

/**
 * Get a PDO connection (singleton)
 * @return PDO
 */
function getPDO(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;

    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
    $opts = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ];

    $pdo = new PDO($dsn, DB_USER, DB_PASS, $opts);
    return $pdo;
}

/**
 * Helper: send JSON response and exit
 */
function set_json_header(): void {
    header('Content-Type: application/json; charset=utf-8');
}
function json_response(array $data, int $status = 200): void {
    http_response_code($status);
    set_json_header();
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}
