<?php
// register.php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (is_ajax()) json_response(['error' => 'Method Not Allowed'], 405);
    http_response_code(405);
    exit('405 Method Not Allowed');
}

$data = get_input_data();

$name = isset($data['name']) ? clean_name((string)$data['name']) : '';
$email = isset($data['email']) ? clean_email((string)$data['email']) : '';
$password = $data['password'] ?? '';
$role = $data['role'] ?? 'client';

global $ALLOWED_ROLES;
$errors = [];

if ($name === '') $errors[] = 'Name is required';
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Invalid email';
if (!is_string($password) || strlen($password) < 8) $errors[] = 'Password must be at least 8 characters';
if (!in_array($role, $ALLOWED_ROLES, true)) $errors[] = 'Invalid role';

if ($errors) {
    if (is_ajax()) json_response(['errors' => $errors], 422);
    http_response_code(422);
    echo implode('; ', $errors);
    exit;
}

try {
    $pdo = getPDO();

    // email uniqueness
    $stmt = $pdo->prepare('SELECT user_id FROM `User` WHERE email = :email LIMIT 1');
    $stmt->execute([':email' => $email]);
    if ($stmt->fetch()) {
        if (is_ajax()) json_response(['error' => 'Email already registered'], 409);
        http_response_code(409);
        echo 'Email already registered';
        exit;
    }

    $hash = password_hash($password, PASSWORD_DEFAULT);

    $insert = $pdo->prepare('INSERT INTO `User` (`name`, `email`, `password`, `role`, `created_at`) VALUES (:name, :email, :password, :role, NOW())');
    $insert->execute([
        ':name' => $name,
        ':email' => $email,
        ':password' => $hash,
        ':role' => $role
    ]);

    $userId = (int)$pdo->lastInsertId();

    // create session
    session_regenerate_id(true);
    $_SESSION['user_id'] = $userId;
    $_SESSION['user_name'] = $name;
    $_SESSION['user_email'] = $email;
    $_SESSION['user_role'] = $role;

    if (is_ajax()) {
        json_response(['ok' => true, 'user' => ['id' => $userId, 'name' => $name, 'role' => $role]]);
    }

    // normal form submit -> redirect
    role_redirect($role);

} catch (Exception $ex) {
    if (is_ajax()) json_response(['error' => 'Server error'], 500);
    http_response_code(500);
    error_log('Register error: ' . $ex->getMessage());
    echo 'Server error';
    exit;
}
