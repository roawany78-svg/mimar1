<?php
// login.php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if (is_ajax()) json_response(['error' => 'Method Not Allowed'], 405);
    http_response_code(405);
    exit('405 Method Not Allowed');
}

$data = get_input_data();
$email = isset($data['email']) ? clean_email((string)$data['email']) : '';
$password = $data['password'] ?? '';

if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password === '') {
    if (is_ajax()) json_response(['error' => 'Missing credentials'], 400);
    http_response_code(400);
    exit('Missing credentials');
}

try {
    $pdo = getPDO();
    $stmt = $pdo->prepare('SELECT user_id, name, password, role FROM `User` WHERE email = :email LIMIT 1');
    $stmt->execute([':email' => $email]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password'])) {
        if (is_ajax()) json_response(['error' => 'Invalid credentials'], 401);
        http_response_code(401);
        exit('Invalid credentials');
    }

    // Login OK
    session_regenerate_id(true);
    $_SESSION['user_id'] = (int)$user['user_id'];
    $_SESSION['user_name'] = $user['name'];
    $_SESSION['user_email'] = $email;
    $_SESSION['user_role'] = $user['role'];

    if (is_ajax()) json_response(['ok' => true, 'user' => ['id' => $user['user_id'], 'name' => $user['name'], 'role' => $user['role']]]);
    role_redirect((string)$user['role']);

} catch (Exception $ex) {
    if (is_ajax()) json_response(['error' => 'Server error'], 500);
    http_response_code(500);
    error_log('Login error: ' . $ex->getMessage());
    echo 'Server error';
    exit;
}
