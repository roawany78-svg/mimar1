<?php
// logout.php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';

// Destroy session safely
$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
}
session_destroy();

if (is_ajax()) {
    json_response(['ok' => true]);
}

// Redirect to login page (adjust path if needed)
$login = (BASE_URL ?: '') . '/Login.html';
header('Location: ' . $login);
exit;
