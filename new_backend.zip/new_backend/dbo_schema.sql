-- Converted MySQL schema (for XAMPP / MySQL 8+)
-- Converted from: dbo_schema (1).sql. See original uploaded file. :contentReference[oaicite:1]{index=1}

SET @@foreign_key_checks = 0;

-- Drop tables if they exist (drop in FK-safe order)
DROP TABLE IF EXISTS `Attachment`;
DROP TABLE IF EXISTS `Offer`;
DROP TABLE IF EXISTS `Message`;
DROP TABLE IF EXISTS `Rating`;
DROP TABLE IF EXISTS `Notification`;
DROP TABLE IF EXISTS `Material`;
DROP TABLE IF EXISTS `Project`;
DROP TABLE IF EXISTS `User`;

SET @@foreign_key_checks = 1;

-- ====================================================
-- 1) Users
-- Notes:
--  - NVARCHAR(...) -> VARCHAR(...) with utf8mb4
--  - NVARCHAR(MAX) -> LONGTEXT
--  - IDENTITY -> AUTO_INCREMENT
--  - SYSUTCDATETIME() -> CURRENT_TIMESTAMP(3) (approximation)
--  - role is implemented as ENUM for stricter validation in MySQL
-- ====================================================
CREATE TABLE `User` (
  `user_id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` VARCHAR(320) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL UNIQUE,
  `password` VARCHAR(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` VARCHAR(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` ENUM('client','contractor','admin') NOT NULL,
  `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX `IX_User_role` ON `User` (`role`);

-- ====================================================
-- 2) Project
-- ====================================================
CREATE TABLE `Project` (
  `project_id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` LONGTEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` VARCHAR(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` VARCHAR(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `client_id` INT NOT NULL,
  CONSTRAINT `FK_Project_Client` FOREIGN KEY (`client_id`) REFERENCES `User`(`user_id`)
    ON UPDATE NO ACTION ON DELETE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX `IX_Project_client` ON `Project` (`client_id`);
CREATE INDEX `IX_Project_status` ON `Project` (`status`);

-- ====================================================
-- 3) Attachment
-- ====================================================
CREATE TABLE `Attachment` (
  `attachment_id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `file_name` VARCHAR(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_type` VARCHAR(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uploaded_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `project_id` INT NOT NULL,
  CONSTRAINT `FK_Attachment_Project` FOREIGN KEY (`project_id`) REFERENCES `Project`(`project_id`)
    ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX `IX_Attachment_project` ON `Attachment` (`project_id`);

-- ====================================================
-- 4) Offer
-- ====================================================
CREATE TABLE `Offer` (
  `offer_id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `price` DECIMAL(12,2) NOT NULL,
  `duration` VARCHAR(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` LONGTEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `project_id` INT NOT NULL,
  `contractor_id` INT NOT NULL,
  CONSTRAINT `FK_Offer_Project` FOREIGN KEY (`project_id`) REFERENCES `Project`(`project_id`)
    ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `FK_Offer_Contractor` FOREIGN KEY (`contractor_id`) REFERENCES `User`(`user_id`)
    ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX `IX_Offer_project` ON `Offer` (`project_id`);
CREATE INDEX `IX_Offer_contractor` ON `Offer` (`contractor_id`);

-- ====================================================
-- 5) Message
-- ====================================================
CREATE TABLE `Message` (
  `message_id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `content` LONGTEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sent_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `sender_id` INT NOT NULL,
  `receiver_id` INT NOT NULL,
  `is_read` TINYINT(1) NOT NULL DEFAULT 0,
  CONSTRAINT `FK_Message_Sender` FOREIGN KEY (`sender_id`) REFERENCES `User`(`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_Message_Receiver` FOREIGN KEY (`receiver_id`) REFERENCES `User`(`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX `IX_Message_sender` ON `Message` (`sender_id`);
CREATE INDEX `IX_Message_receiver` ON `Message` (`receiver_id`);

-- ====================================================
-- 6) Rating
-- ====================================================
CREATE TABLE `Rating` (
  `rating_id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `stars` TINYINT UNSIGNED NOT NULL,
  `comment` LONGTEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `rated_by` INT NOT NULL,
  `contractor_id` INT NOT NULL,
  CONSTRAINT `FK_Rating_RatedBy` FOREIGN KEY (`rated_by`) REFERENCES `User`(`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_Rating_Contractor` FOREIGN KEY (`contractor_id`) REFERENCES `User`(`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `CHK_Rating_Stars` CHECK (`stars` BETWEEN 1 AND 5)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX `IX_Rating_contractor` ON `Rating` (`contractor_id`);

-- ====================================================
-- 7) Notification
-- ====================================================
CREATE TABLE `Notification` (
  `notification_id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `content` LONGTEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_read` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `user_id` INT NOT NULL,
  CONSTRAINT `FK_Notification_User` FOREIGN KEY (`user_id`) REFERENCES `User`(`user_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX `IX_Notification_user` ON `Notification` (`user_id`);

-- ====================================================
-- 8) Material
-- ====================================================
CREATE TABLE `Material` (
  `material_id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` DECIMAL(12,2) DEFAULT NULL,
  `unit` VARCHAR(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `added_by` INT NOT NULL,
  CONSTRAINT `FK_Material_AddedBy` FOREIGN KEY (`added_by`) REFERENCES `User`(`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX `IX_Material_added_by` ON `Material` (`added_by`);

-- Final message (optional)
-- SELECT 'Schema created successfully.' AS msg;
