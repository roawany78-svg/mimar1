<?php
// functions.php - helper functions
require_once __DIR__ . '/config.php';

/**
 * Detect AJAX (XHR/fetch) requests
 */
function is_ajax(): bool {
    return (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest')
        || (isset($_SERVER['HTTP_ACCEPT']) && str_contains($_SERVER['HTTP_ACCEPT'], 'application/json'));
}

/**
 * Basic sanitizers
 */
function clean_name(string $v): string {
    $v = trim($v);
    // allow letters, spaces and basic punctuation; limit length
    $v = preg_replace('/[^\p{L}\p{N}\s\-\._,]/u', '', $v);
    return mb_substr($v, 0, 200);
}
function clean_email(string $v): string {
    return mb_substr(trim($v), 0, 320);
}

/**
 * Map role -> frontend path and redirect
 */
function role_redirect(string $role): void {
    $map = [
        'client' => (BASE_URL ?: '') . '/cei.html',
        'contractor' => (BASE_URL ?: '') . '/pro.html',
        'admin' => (BASE_URL ?: '') . '/ad.html',
    ];
    $url = $map[$role] ?? (BASE_URL ?: '/') ;
    header('Location: ' . $url);
    exit;
}

/**
 * Safe JSON input reader (works for application/json and form posts)
 */
function get_input_data(): array {
    $raw = file_get_contents('php://input');
    $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
    if (str_contains($contentType, 'application/json')) {
        $data = json_decode($raw, true);
        if (is_array($data)) return $data;
        return [];
    }
    return $_POST;
}
