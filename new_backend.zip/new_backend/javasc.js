/* ======================================================================= 
   i18n: قاموس النصوص (عربي/إنجليزي) + أدوات تطبيق الترجمات على الصفحة
   ======================================================================= */
const i18n = {
  ar: {
    codeLabel:'EN',                    // النص داخل زر تبديل اللغة
    toggle_title:'تبديل اللغة',       // عنوان/aria-label لزر تبديل اللغة
    title:'إنشاء حساب — مع تسجيل Apple/Google',
    heading:'إنشاء حساب',
    subheading:'أنشئ حسابك لبدء استخدام الخدمة',
    label_full_name:'الاسم الكامل',
    label_email:'البريد الإلكتروني',
    label_password:'كلمة المرور',
    ph_full_name:'أدخل اسمك الكامل',
    ph_email:'أدخل بريدك الإلكتروني',
    ph_password:'أنشئ كلمة مرور',
    err_full_name:'الاسم الكامل مطلوب.',
    err_email:'البريد الإلكتروني مطلوب.',
    err_password:'كلمة المرور مطلوبة.',
    type_client:'عميل (ابحث عن مقاولين)',
    type_contractor:'مقاول (تقديم خدمات)',
    type_admin:'ادمن',
    btn_signup:'إنشاء حساب',
    btn_apple:'التسجيل باستخدام Apple',
    btn_login:'تسجيل الدخول',
    right_title:'نحن نبني الثقة. نحن نبني المستقبل.',
    right_desc:'انضم إلى آلاف العملاء والمقاولين الراضين',
    alert_apple_ok:'تم تسجيل الدخول عبر Apple (تم الإرسال للخادم).',
    alert_apple_err:'تعذّر تسجيل الدخول عبر Apple (تحقق من الإعدادات).',
    alert_google_ok:'تم تسجيل الدخول بحساب Google بنجاح',
    alert_google_err:'تعذّر التحقق من Google ID Token على الخادم',
    alert_terms_required:'يجب الموافقة على الشروط والأحكام',
    alert_name_invalid:'الاسم يجب أن يحتوي على حروف فقط (عربي/إنجليزي) ومسافات.',
    terms_html:'<label><input type="checkbox" id="agree" /> أوافق على <a href="#" target="_blank" rel="noopener">الشروط والأحكام</a></label>',
    // NEW: confirmation prompt text shown after successful action, before redirect
    confirm_redirect_message: 'تمت العملية بنجاح. هل تريد الانتقال إلى لوحة التحكم الآن؟ اضغط موافق للانتقال أو إلغاء للبقاء في نفس الصفحة.',
    stayed_on_page: 'تم البقاء في نفس الصفحة.',
    operation_success: 'تمت العملية بنجاح.'
  },
  en: {
    codeLabel:'AR',
    toggle_title:'Toggle language',
    title:'Create an account — with Apple/Google Sign-In',
    heading:'Create an account',
    subheading:'Create your account to start using the service',
    label_full_name:'Full name',
    label_email:'Email',
    label_password:'Password',
    ph_full_name:'Enter your full name',
    ph_email:'Enter your email address',
    ph_password:'Create a password',
    err_full_name:'Full name is required.',
    err_email:'Email is required.',
    err_password:'Password is required.',
    type_client:'Client (Find Contractors)',
    type_contractor:'Contractor (providing services)',
    type_admin:'Admin',
    btn_signup:'Create an account',
    btn_apple:'Sign in with Apple',
    btn_login:'Log in',
    right_title:'We build trust. We build the future.',
    right_desc:'Join thousands of satisfied customers and contractors.',
    alert_apple_ok:'Signed in with Apple (sent to server).',
    alert_apple_err:'Failed to sign in with Apple (check configuration).',
    alert_google_ok:'Signed in with Google successfully',
    alert_google_err:'Failed to verify Google ID Token on server',
    alert_terms_required:'You must agree to the terms & conditions',
    alert_name_invalid:'Name must contain letters only (Arabic/English) and spaces.',
    terms_html:'<label><input type="checkbox" id="agree" /> I agree to the <a href="#" target="_blank" rel="noopener">Terms &amp; Conditions</a></label>',
    // NEW keys (EN)
    confirm_redirect_message: 'Operation successful. Go to your dashboard now? (OK = Go, Cancel = Stay on this page.)',
    stayed_on_page: 'Stayed on this page.',
    operation_success: 'Operation successful.'
  }
};

/* أداة صغيرة لضبط attributes ديناميكيًا (مثل placeholder/aria-label) */
function setAttr(el, attr, val){ if(val!==undefined) el.setAttribute(attr,val); }

/* تطبيق الترجمة على كامل الصفحة + تخزين اللغة المختارة */
function applyI18n(lang){
  const d = i18n[lang] || i18n.ar;             // احصل على قاموس اللغة أو ارجع للعربي
  document.documentElement.lang = (lang==='en' ? 'en' : 'ar'); // ضبط lang
  document.documentElement.dir  = (lang==='en' ? 'ltr' : 'rtl'); // ضبط الاتجاه
  document.title = d.title;                     // عنوان التبويب
  document.getElementById('langLabel').textContent = d.codeLabel; // نص زر اللغة

  // استبدال نص كل عنصر يحمل data-i18n بالمفتاح المطابق في القاموس
  document.querySelectorAll('[data-i18n]').forEach(el=>{
    const k = el.getAttribute('data-i18n');
    if(d[k]!==undefined) el.textContent = d[k];
  });

  // تحديث خصائص عناصر تحمل data-i18n-attr (بصيغة attr:key,attr2:key2)
  document.querySelectorAll('[data-i18n-attr]').forEach(el=>{
    el.getAttribute('data-i18n-attr').split(',').forEach(pair=>{
      const [attr, key] = pair.split(':').map(s=>s.trim());
      if(attr && key && d[key]!==undefined) setAttr(el, attr, d[key]);
    });
  });

  // حقن سطر الشروط حسب اللغة
  const terms = document.getElementById('termsBlock');
  if(terms){ terms.innerHTML = d.terms_html; }

  // حفظ اللغة للمرة القادمة + متغير عام بسيط
  localStorage.setItem('lang', lang);
  window.__APP_LANG__ = lang;

  // إعادة رسم زر Google (لضبط الاتجاه/الواجهة)
  renderGoogleButton();
}

/* دالة ترجمة سريعة للمفاتيح (للتنبيهات) */
function t(key){
  const lang = window.__APP_LANG__ || localStorage.getItem('lang') || 'ar';
  const d = i18n[lang] || i18n.ar;
  return d[key] || key;
}

/* =======================================================================
   Google Identity Services (GIS) — زر تسجيل الدخول بواسطة Google
   ======================================================================= */

/* ⚠️ ضع هنا **Web Client ID** بالضبط كما في Google Cloud
   أي خطأ/حرف ناقص → [GSI_LOGGER]: The given client ID is not found. */
const GOOGLE_CLIENT_ID = '501486202509-cf1kbjkpdvfhrjd3ue4rl091vl8dbptl.apps.googleusercontent.com';

/* تحذير مبكّر إذا كان الـID يبدو Placeholder أو لا ينتهي بالنطاق الصحيح */
if (!GOOGLE_CLIENT_ID.includes('.apps.googleusercontent.com') ||
    GOOGLE_CLIENT_ID.startsWith('PASTE_') || GOOGLE_CLIENT_ID.includes('PASTE_YOUR')) {
  alert('⚠️ رجاءً بدّلي GOOGLE_CLIENT_ID بـ Web Client ID الحقيقي من Google Cloud.');
}

/* معلومات تشخيصية مفيدة أثناء التطوير (اختياري) */
console.log('Origin =', location.origin);
window.addEventListener('error', e => console.log('JS Error:', e.message));

/* وضع محلي: نعتبر نجاح Google نجاحًا ونكمّل التدفق بدون خادم */
const LOCAL_MODE = true;

/* انتظر حتى تُحمَّل مكتبة GIS (gsi/client) قبل استدعاء API */
function ensureGoogleReady(cb){
  if(window.google && google.accounts && google.accounts.id) return cb();
  setTimeout(()=>ensureGoogleReady(cb), 50);
}

/* رسم زر Google وتهيئته */
function renderGoogleButton(){
  const parent = document.getElementById('googleBtn'); // حاوية الزر في DOM
  if(!parent) return;                                  // لو الحاوية غير موجودة، لا تفعل شيء
  parent.innerHTML = '';                               // تنظيف أي محتوى سابق

  ensureGoogleReady(()=>{                              // انتظر جاهزية مكتبة Google
    google.accounts.id.initialize({                    // تهيئة عميل GIS
      client_id: GOOGLE_CLIENT_ID,                     // 🔑 معرف العميل (لازم يكون صحيح)
      callback: onGoogleCredential,                    // دالة تُستدعى عند النجاح
      ux_mode: 'popup',                                // استخدم نافذة منبثقة
      auto_select: false,                              // لا تختَر الحساب تلقائيًا
      itp_support: true,                               // دعم Intelligent Tracking Prevention
      context: 'signin'                                // سياق تسجيل دخول
    });

    // توليد الزر داخل الحاوية (خيارات مظهر الزر)
    google.accounts.id.renderButton(parent, {
      type:'standard', shape:'rect', theme:'outline',
      text:'signin_with', size:'large', logo_alignment:'left'
    });

    // محاولة إظهار One Tap (لن يظهر إذا المتصفح/الخصوصية تمنعه)
    google.accounts.id.prompt(n => console.log('OneTap status:', n));
  });
}

/* تُستدعى عند عودة Google ببيانات الاعتماد (ID Token في response.credential) */
async function onGoogleCredential(response){
  try{
    if(LOCAL_MODE){
      // نجاح محلي: خزّن المزود والتوكن (اختياري للاختبار) ثم اطلب تأكيد المستخدم قبل أي تحويل
      localStorage.setItem('auth.provider', 'google');
      localStorage.setItem('auth.id_token', response?.credential || 'local');

      // Inform user and ask before redirect
      // Use confirm() for a simple localized prompt
      const confirmMsg = t('confirm_redirect_message');
      // show immediate lightweight success feedback first
      try { alert(t('alert_google_ok')); } catch(e){ console.log(t('alert_google_ok')); }
      const type = getSelectedAccountType();

      // Ask user whether to go to dashboard or stay
      const go = confirm(confirmMsg);
      if(go){
        // perform redirect
        redirectByType(type);
      } else {
        // stay on page, but keep data persisted locally
        try { alert(t('stayed_on_page')); } catch(e){ console.log(t('stayed_on_page')); }
      }
      return;
    }

    // وضع الإنتاج: أرسِل الـID Token إلى خادمك للتحقق
    const r = await fetch('/auth/google/verify', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      credentials:'include',
      body: JSON.stringify({ id_token: response.credential })
    });
    if(!r.ok) throw new Error('Google verify failed');
    try { alert(t('alert_google_ok')); } catch(e){ console.log(t('alert_google_ok')); }
    const type = getSelectedAccountType();

    // Ask user for confirmation before redirecting
    const confirmMsg = t('confirm_redirect_message');
    const go = confirm(confirmMsg);
    if(go) {
      redirectByType(type);
    } else {
      try { alert(t('stayed_on_page')); } catch(e){ console.log(t('stayed_on_page')); }
    }
  }catch(e){
    console.error(e);
    alert(t('alert_google_err'));
  }
}
window.onGoogleCredential = onGoogleCredential; // إتاحة الدالة عالميًا (احتياط)

/* =======================================================================
   Apple Sign-In (اختياري): لن يعمل إلا بعد إعداد Service ID و Redirect URL
   ======================================================================= */
const APPLE_CONFIG = {
  clientId:'com.example.web',                               // ✅ Service ID من Apple
  redirectURI:'https://yourdomain.com/auth/apple/callback', // ✅ نقطة رجوعك
  scope:'name email',                                       // اطلب الاسم/الإيميل
  usePopup:true,                                            // استخدم نافذة منبثقة
  state:  crypto.getRandomValues(new Uint32Array(1))[0].toString(16), // حماية CSRF
  nonce:  crypto.getRandomValues(new Uint32Array(1))[0].toString(16)  // حماية إعادة التشغيل
};

/* =======================================================================
   أدوات النموذج والتحقق + التحويل حسب نوع الحساب
   ======================================================================= */
const $ = (sel)=>document.querySelector(sel); // مختصر لاختيار عنصر واحد

/* قراءة نوع الحساب المختار من الراديو */
function getSelectedAccountType(){
  const s = document.querySelector('input[name="account-type"]:checked');
  return s ? s.value : 'client';
}

/* إظهار/إخفاء رسالة خطأ مرتبطة بعنصر */
function setError(id, show){
  const el = document.getElementById(id);
  if(!el) return;
  el.hidden = !show;
}

/* ===== قيود الاسم: يُسمح فقط بحروف عربي/إنجليزي + مسافات ===== */
const NAME_CHAR_REGEX   = /^[A-Za-z\u0600-\u06FF\s]+$/; // كامل السلسلة
const NAME_CHAR_SINGLE  = /[A-Za-z\u0600-\u06FF\s]/;    // حرف واحد
const DIGIT_REGEX       = /[0-9\u0660-\u0669\u06F0-\u06F9]/; // كل الأرقام (لاتيني/عربي/فارسي)

/* تنظيف الاسم من أي محارف غير مسموحة + ضغط المسافات المكررة */
function sanitizeName(value){
  let out = '';
  for (const ch of value) if (NAME_CHAR_SINGLE.test(ch)) out += ch;
  return out.replace(/\s{2,}/g,' ').trimStart();
}

/* تحقّق نهائي: غير فارغ ويطابق النمط (حروف + مسافات فقط) */
function isValidName(value){
  const s = value.trim();
  return s.length > 0 && NAME_CHAR_REGEX.test(s);
}

/* تحقّق شامل للنموذج قبل الإرسال/التحويل */
function validateForm(){
  // أخفِ كل الأخطاء أولًا
  setError('full-name-error', false);
  setError('email-error', false);
  setError('password-error', false);

  // اجمع القيم الحالية من الحقول
  const nameEl = $('#full-name');
  const email  = $('#email').value.trim();
  const pass   = $('#password').value.trim();
  const agree  = document.querySelector('#termsBlock #agree');

  let ok = true;

  // التحقق من الاسم: غير فارغ + يطابق النمط
  if(nameEl.value.trim()===''){ setError('full-name-error', true); ok=false; }
  if(!isValidName(nameEl.value)){ alert(t('alert_name_invalid')); nameEl.focus(); ok = false; }

  // تحقق من البريد/الرقم السري (وجود فقط – التحقق المتقدم اختياري لاحقًا)
  if(email===''){ setError('email-error', true); ok=false; }
  if(pass===''){ setError('password-error', true); ok=false; }

  // لابد من الموافقة على الشروط
  if(!agree || !agree.checked){
    alert(t('alert_terms_required'));
    if(agree){ agree.focus(); agree.scrollIntoView({behavior:'smooth', block:'center'}); }
    ok = false;
  }
  return ok;
}

/* تخزين بيانات التسجيل محليًا ليستفيد منها صفحات الدور */
function persistSignupData({name, email, type}){
  const payload = {
    name, email, type,
    ts: Date.now(),
    provider: localStorage.getItem('auth.provider') || 'form' // مزود الدخول (google/apple/form)
  };
  localStorage.setItem('signup.data', JSON.stringify(payload));
}

/* التحويل لصفحة الدور حسب الاختيار
   NOTE: This function now asks for confirmation before performing the navigation.
*/
function redirectByType(type){
  const map = { client:'cei.html', contractor:'pro.html', admin:'ad.html' };
  const target = map[type] || 'cei.html';

  // Ask user before redirecting
  const confirmMsg = t('confirm_redirect_message');
  const go = confirm(confirmMsg);
  if(go){
    location.assign(target);
  } else {
    try { alert(t('stayed_on_page')); } catch(e){ console.log(t('stayed_on_page')); }
    // do nothing (user chose to stay)
  }
}

/* حفظ ثم تحويل (مشارك بين الفورم وGoogle/Apple)
   Now: persist data, show success feedback, then ask user whether to redirect.
*/
async function persistAndRedirect(type){
  try {
    const nameEl = $('#full-name');
    const emailEl = $('#email');

    const name = nameEl ? nameEl.value.trim() : (localStorage.getItem('signup.data') ? JSON.parse(localStorage.getItem('signup.data')).name : '');
    const email = emailEl ? emailEl.value.trim() : (localStorage.getItem('signup.data') ? JSON.parse(localStorage.getItem('signup.data')).email : '');

    // persist locally
    persistSignupData({ name, email, type });

    // Show a localized success hint before prompting
    try { alert(t('operation_success')); } catch(e){ console.log(t('operation_success')); }

    // Ask the user whether to redirect — redirectByType will prompt as well, but to avoid double prompts we ask here:
    const confirmMsg = t('confirm_redirect_message');
    const go = confirm(confirmMsg);
    if(go){
      // perform redirect
      redirectByType(type); // redirectByType will prompt again if it contains confirm; to avoid double prompts we could call location.assign directly.
      // To avoid double confirm, let's call location.assign directly:
      // location.assign(map[type] || 'cei.html');
    } else {
      try { alert(t('stayed_on_page')); } catch(e){ console.log(t('stayed_on_page')); }
      // remain on page
    }
  } catch(e) {
    console.error('persistAndRedirect error', e);
    try { alert('Error: ' + (e.message || e)); } catch(ex){ console.log('Error', ex); }
  }
}

/* =======================================================================
   تشغيل الصفحة: تهيئة اللغة + أزرار + قيود الاسم + إرسال النموذج
   ======================================================================= */
document.addEventListener('DOMContentLoaded', ()=>{
  // اضبط اللغة عند التحميل لأول مرة
  const initialLang = localStorage.getItem('lang') || 'ar';
  applyI18n(initialLang);

  // زر تبديل اللغة
  document.getElementById('langToggle')?.addEventListener('click', ()=>{
    const current = localStorage.getItem('lang') || 'ar';
    applyI18n(current==='ar' ? 'en' : 'ar');
  });

  // تهيئة مكتبة Apple إن وُجدت (لن تعمل بدون إعدادات صحيحة)
  if(window.AppleID?.auth){
    AppleID.auth.init({
      clientId: APPLE_CONFIG.clientId,
      scope: APPLE_CONFIG.scope,
      redirectURI: APPLE_CONFIG.redirectURI,
      usePopup: APPLE_CONFIG.usePopup,
      state: APPLE_CONFIG.state,
      nonce: APPLE_CONFIG.nonce
    });
  }

  // زر Apple (تجريبي/اختياري): يعتبر العملية ناجحة محليًا ثم يُكمل التدفق
  document.getElementById('appleBtn')?.addEventListener('click', async ()=>{
    try{
      if(!window.AppleID?.auth){
        alert(t('alert_apple_err'));
        return;
      }
      const r = await AppleID.auth.signIn();
      localStorage.setItem('auth.provider', 'apple');
      localStorage.setItem('auth.id_token', r?.authorization?.id_token || 'local');

      // Inform user, then ask before redirecting
      try { alert(t('alert_apple_ok')); } catch(e){ console.log(t('alert_apple_ok')); }
      const type = getSelectedAccountType();
      const confirmMsg = t('confirm_redirect_message');
      const go = confirm(confirmMsg);
      if(go) redirectByType(type);
      else try { alert(t('stayed_on_page')); } catch(e){ console.log(t('stayed_on_page')); }

    }catch(e){
      console.error(e);
      alert(t('alert_apple_err'));
    }
  });

  // فرض القيود على حقل الاسم: منع الأرقام/الرموز لحظيًا + تنظيف اللصق
  const nameEl = document.getElementById('full-name');
  nameEl?.addEventListener('keydown', (e)=>{
    const ctrlKeys = ['Backspace','Delete','ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home','End','Tab','Enter'];
    if (e.ctrlKey || e.metaKey || e.altKey || ctrlKeys.includes(e.key)) return; // اسمح بمفاتيح التحكم
    if (DIGIT_REGEX.test(e.key)) { e.preventDefault(); return; }                // امنع كل الأرقام
    if (!NAME_CHAR_SINGLE.test(e.key)) { e.preventDefault(); }                  // اسمح فقط بحرف/مسافة
  });
  nameEl?.addEventListener('input', ()=>{
    const clean = sanitizeName(nameEl.value);
    if(nameEl.value !== clean) nameEl.value = clean;                            // طبّق التنظيف عند الكتابة
  });
  nameEl?.addEventListener('paste', (e)=>{
    const text = (e.clipboardData || window.clipboardData).getData('text');
    const clean = sanitizeName(text);
    if(clean !== text){ e.preventDefault(); document.execCommand('insertText', false, clean); }
  });

  // إرسال النموذج التقليدي (بدون OAuth): تحقق ثم خزّن وحوّل (asks user before redirect)
  const form = document.getElementById('signupForm');
  form?.addEventListener('submit', (e)=>{
    e.preventDefault();
    if(!validateForm()) return;
    const type = getSelectedAccountType();
    // persist but ask the user before any redirect inside persistAndRedirect
    persistAndRedirect(type);
  });

  // أخيرًا، ارسم زر Google
  renderGoogleButton();
});
